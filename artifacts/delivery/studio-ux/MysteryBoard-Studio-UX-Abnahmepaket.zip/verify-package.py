from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
for entry in manifest:
 p=root/entry['file']; data=p.read_bytes()
 assert len(data)==entry['bytes'],entry['file']
 assert hashlib.sha256(data).hexdigest()==entry['sha256'],entry['file']
 if p.suffix=='.zip':
  with zipfile.ZipFile(p) as z: assert z.testzip() is None,p
print(f"Vollständig: {len(manifest)} Dateien, sämtliche SHA-256 und enthaltene ZIP-CRC korrekt.")
