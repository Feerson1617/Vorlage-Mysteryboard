# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: png-saving.spec.ts >> PNG-Schülersicherung html 320: echter Downloadname, MBX3, neue Sitzung und Weiterarbeit
- Location: tests/browser/png-saving.spec.ts:216:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('dialog', { name: 'Arbeitsstand sichern', exact: true })
Expected: visible
Timeout: 8000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('dialog', { name: 'Arbeitsstand sichern', exact: true }) with timeout 8000ms
  - waiting for getByRole('dialog', { name: 'Arbeitsstand sichern', exact: true })

```

```yaml
- main:
  - navigation "Arbeitsfläche bedienen":
    - button "Übersicht"
    - button "Rückgängig"
    - button "Wiederholen" [disabled]
    - button "Sichern"
    - button "Menü": ⋯
  - text: Orientierungshilfe ausgeschaltet.
  - group "Arbeitsfläche":
    - 'button "Verbindung 1 zu 2: beeinflusst die Beobachtung"'
    - 'button "Verbindung 3 zu 4: wird geprüft"'
    - text: beeinflusst die Beobachtung wird geprüft
    - button "Karte 3 öffnen": Beobachtung 3 Neutrale Information 3. Prüft, welcheanderen Beobachtungen damitzusammenhängen könnten. DieNummer gibt keine Lösung vor. 3
    - button "Karte 4 öffnen": Beobachtung 4 Neutrale Information 4. Prüft, welcheanderen Beobachtungen damitzusammenhängen könnten. DieNummer gibt keine Lösung vor. 4
    - button "Karte 5 öffnen": Beobachtung 5 Neutrale Information 5. Prüft, welcheanderen Beobachtungen damitzusammenhängen könnten. DieNummer gibt keine Lösung vor. 5
    - button "Karte 6 öffnen": Beobachtung 6 Neutrale Information 6. Prüft, welcheanderen Beobachtungen damitzusammenhängen könnten. DieNummer gibt keine Lösung vor. 6
    - button "Karte 7 öffnen": Beobachtung 7 Neutrale Information 7. Prüft, welcheanderen Beobachtungen damitzusammenhängen könnten. DieNummer gibt keine Lösung vor. 7
    - button "Karte 8 öffnen": Beobachtung 8 Neutrale Information 8. Prüft, welcheanderen Beobachtungen damitzusammenhängen könnten. DieNummer gibt keine Lösung vor. 8
    - button "Karte 9 öffnen": Beobachtung 9 Neutrale Information 9. Prüft, welcheanderen Beobachtungen damitzusammenhängen könnten. DieNummer gibt keine Lösung vor. 9
    - button "Karte V10 öffnen": Beobachtung 10 Neutrale Information 10. Prüft,welche anderen Beobachtungendamit zusammenhängen könnten.Die Nummer gibt keine Lösung vor. V10
    - button "Karte V11 öffnen": Beobachtung 11 Neutrale Information 11. Prüft,welche anderen Beobachtungendamit zusammenhängen könnten.Die Nummer gibt keine Lösung vor. V11
    - button "Karte V12 öffnen": Beobachtung 12 Neutrale Information 12. Prüft,welche anderen Beobachtungendamit zusammenhängen könnten.Die Nummer gibt keine Lösung vor. V12
    - button "Karte 2 öffnen": Beobachtung 2 Neutrale Information 2. Prüft, welcheanderen Beobachtungen damitzusammenhängen könnten. DieNummer gibt keine Lösung vor. 2
    - button "Karte 1 öffnen": Beobachtung 1 Neutrale Information 1. Prüft, welcheanderen Beobachtungen damitzusammenhängen könnten. DieNummer gibt keine Lösung vor. 1
```

# Test source

```ts
  1   | import { test, expect, type Browser, type TestInfo } from "@playwright/test";
  2   | import { readFile, writeFile, mkdir, copyFile } from "node:fs/promises";
  3   | import { join } from "node:path";
  4   | import { execFileSync } from "node:child_process";
  5   | import source from "../../examples/universal/content.json" with { type: "json" };
  6   | import {
  7   |   taskDocument,
  8   |   encodeDocument,
  9   |   type Student,
  10  | } from "../../src/core/documents";
  11  | import { draftFromContent } from "../../src/core/authoring";
  12  | import {
  13  |   button,
  14  |   openUniversal,
  15  |   importMystery,
  16  |   getFile,
  17  |   rootPage,
  18  |   type UI,
  19  | } from "./authoring-helpers";
  20  | import { scorm, gestures, connect } from "./help-runtime-helpers";
  21  | import { classroom, downloadClassroom } from "./pdf-region-helpers";
  22  | test.use({ hasTouch: true });
  23  | 
  24  | const title = "Strömungen und Küsten – Übungsaufgabe",
  25  |   team = "Team Nordseeküste";
  26  | const task = () => taskDocument({ ...source, title });
  27  | async function output(info: TestInfo, path: string, name: string) {
  28  |   if (process.env.TOUCH_EVIDENCE_DIR) {
  29  |     await mkdir(process.env.TOUCH_EVIDENCE_DIR, { recursive: true });
  30  |     await copyFile(path, join(process.env.TOUCH_EVIDENCE_DIR, name));
  31  |   }
  32  |   await info.attach(name, { path });
  33  | }
  34  | async function trace(ui: UI) {
  35  |   await ui.evaluate(() => {
  36  |     const w = window as any;
  37  |     if (w.__savingEvents) return;
  38  |     w.__savingEvents = [];
  39  |     for (const type of [
  40  |       "pointerdown",
  41  |       "pointermove",
  42  |       "pointerup",
  43  |       "pointercancel",
  44  |       "lostpointercapture",
  45  |       "click",
  46  |     ])
  47  |       window.addEventListener(
  48  |         type,
  49  |         (event) => {
  50  |           const e = event as PointerEvent,
  51  |             n = e.target as Element;
  52  |           const item = {
  53  |             type,
  54  |             id: e.pointerId,
  55  |             pointerType: e.pointerType,
  56  |             x: e.clientX,
  57  |             y: e.clientY,
  58  |             detail: e.detail,
  59  |             target:
  60  |               n
  61  |                 .closest("button, [data-card], svg.board")
  62  |                 ?.getAttribute("aria-label") ||
  63  |               n.closest("button")?.textContent ||
  64  |               n.tagName,
  65  |             prevented: false,
  66  |             time: performance.now(),
  67  |           };
  68  |           w.__savingEvents.push(item);
  69  |           queueMicrotask(() => {
  70  |             item.prevented = e.defaultPrevented;
  71  |           });
  72  |         },
  73  |         true,
  74  |       );
  75  |   });
  76  | }
  77  | async function save(ui: UI, info: TestInfo, name: string, compact = false) {
  78  |   if (compact) {
  79  |     await button(ui, "Menü").tap();
  80  |     await expect(button(ui, "Projektdatei sichern")).toHaveCount(0);
  81  |     await button(ui, "Kleineres Sicherungsbild").tap();
  82  |   } else await button(ui, "Sichern").tap();
  83  |   try {
  84  |     await expect(
  85  |       ui.getByRole("dialog", { name: "Arbeitsstand sichern", exact: true }),
> 86  |     ).toBeVisible();
      |       ^ Error: expect(locator).toBeVisible() failed
  87  |   } catch (error) {
  88  |     const trace = info.outputPath(name + "-pointer-click.json");
  89  |     await writeFile(
  90  |       trace,
  91  |       JSON.stringify(
  92  |         await ui.evaluate(() => (window as any).__savingEvents),
  93  |         null,
  94  |         2,
  95  |       ),
  96  |     );
  97  |     await output(info, trace, name + "-pointer-click.json");
  98  |     throw error;
  99  |   }
  100 |   const link = ui.getByRole("link", {
  101 |     name: "Sicherungsbild herunterladen",
  102 |     exact: true,
  103 |   });
  104 |   await expect(link).toBeVisible({ timeout: 60000 });
  105 |   const url = await link.getAttribute("href");
  106 |   expect(
  107 |     await ui.evaluate(
  108 |       async (url) => (await fetch(url!)).headers.get("content-type"),
  109 |       url,
  110 |     ),
  111 |   ).toBe("image/png");
  112 |   const file = await getFile(
  113 |     ui,
  114 |     info,
  115 |     name + ".png",
  116 |     "Sicherungsbild herunterladen",
  117 |   );
  118 |   expect(file.filename).toBe(`${team}_${title}.png`);
  119 |   expect(file.bytes.subarray(0, 8)).toEqual(
  120 |     Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
  121 |   );
  122 |   const path = info.outputPath(name + ".png"),
  123 |     independent = info.outputPath(name + "-unabhaengig.json");
  124 |   const result = JSON.parse(
  125 |     execFileSync(
  126 |       "python3",
  127 |       ["qa/touch-saving/verify-png.py", path, independent],
  128 |       { encoding: "utf8" },
  129 |     ),
  130 |   );
  131 |   expect(JSON.parse(await readFile(independent, "utf8"))).toEqual(
  132 |     file.document,
  133 |   );
  134 |   await writeFile(
  135 |     info.outputPath(name + "-pruefung.json"),
  136 |     JSON.stringify({ ...result, actualDownloadName: file.filename }, null, 2),
  137 |   );
  138 |   await output(info, path, name + ".png");
  139 |   await output(info, independent, name + "-unabhaengig.json");
  140 |   await output(
  141 |     info,
  142 |     info.outputPath(name + "-pruefung.json"),
  143 |     name + "-pruefung.json",
  144 |   );
  145 |   await button(ui, "Schließen").tap();
  146 |   return file;
  147 | }
  148 | async function state(ui: UI) {
  149 |   return ui.evaluate(() => ({
  150 |     cards: [...document.querySelectorAll("[data-card]")].map((n) => ({
  151 |       id: Number(n.getAttribute("data-card")),
  152 |       x: Number(n.getAttribute("data-x")),
  153 |       y: Number(n.getAttribute("data-y")),
  154 |       fill: n.querySelector("rect")!.getAttribute("fill"),
  155 |     })),
  156 |     edges: [...document.querySelectorAll("[data-edge]")].map((n) => ({
  157 |       id: Number(n.getAttribute("data-edge")),
  158 |       label: document.querySelector(
  159 |         `[data-edge-label="${n.getAttribute("data-edge")}"]`,
  160 |       )?.textContent,
  161 |       direction: Number(
  162 |         document
  163 |           .querySelector(`[data-arrowhead="${n.getAttribute("data-edge")}"]`)
  164 |           ?.getAttribute("data-direction") || 0,
  165 |       ),
  166 |     })),
  167 |     team: document.querySelector(".team-summary")?.textContent,
  168 |   }));
  169 | }
  170 | async function moveSecond(ui: UI) {
  171 |   const page = rootPage(ui),
  172 |     session = await page.context().newCDPSession(page),
  173 |     b = (await ui.locator('[data-card="2"] > rect').boundingBox())!;
  174 |   const x = b.x + b.width / 2,
  175 |     y = b.y + Math.min(15, b.height / 3);
  176 |   await session.send("Input.dispatchTouchEvent", {
  177 |     type: "touchStart",
  178 |     touchPoints: [{ id: 1, x, y }],
  179 |   });
  180 |   await session.send("Input.dispatchTouchEvent", {
  181 |     type: "touchMove",
  182 |     touchPoints: [{ id: 1, x: x + 21, y: y + 13 }],
  183 |   });
  184 |   await session.send("Input.dispatchTouchEvent", {
  185 |     type: "touchEnd",
  186 |     touchPoints: [],
```