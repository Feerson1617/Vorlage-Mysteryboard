# MysteryBoard – lokale OCR

Für itslearning das unveränderte `Anwendungen/MysteryBoard-OCR-SCORM-1.2.zip` als SCORM 1.2 importieren. Es enthält den universellen Editor und sämtliche lokalen OCR-Dateien.

Für den lokalen Computer `MysteryBoard-OCR-Autorenpaket.zip` vollständig entpacken und `python3 start-ocr.py` ausführen (Python 3 kostenlos). Auf dem Mac ist START.command als Starthilfe enthalten. Die mehrteilige OCR-Fassung benötigt diesen lokalen Server; die normale Universal-HTML funktioniert weiterhin ohne OCR-Zusatzdateien.

`Beispiel/` enthält einen tatsächlich im Browser erzeugten Entwurf, sein schlankes Unterrichts-SCORM ohne OCR-Dateien und eine tatsächlich gesicherte Schüler-PNG. Die Quellen und alle ursprünglichen Tests stehen in `Quellcode/`.

`OCR-ABNAHMEBERICHT.md` nennt Messergebnisse, Fehlergrenzen und offene reale Geräte-/LMS-Tests. Testfotos sind eigene synthetische Bildbedingungen; keine echte Kameraabnahme. OCR ist kein fachlicher Prüfer. Jede Karte, Zahl, Quelle und Bezeichnung am Original kontrollieren.

Die eingefrorene Boden-RC2 und main wurden nicht verändert. Kein Release, keine Pages-Veröffentlichung, kein Merge. Private Unterrichtsoriginale sind nicht in diesem öffentlich bereitstellbaren Paket enthalten.

Integrität prüfen: `python3 Pruefen.py` im entpackten Ordner. Entwicklungsprüfung: `npm ci` und `npm run check` im Quellcode-Ordner (Node 24, Python 3, Chromium/Playwright erforderlich). Die fertige Autorenfassung benötigt npm nicht. Detaillierte Befehle stehen im Prüfbericht.
