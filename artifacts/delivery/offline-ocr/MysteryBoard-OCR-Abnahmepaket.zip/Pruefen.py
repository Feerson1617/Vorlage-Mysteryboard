#!/usr/bin/env python3
import pathlib,json,hashlib,zipfile,tempfile
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
for f in manifest:
 p=root/f['file'];assert p.is_file(),f['file'];b=p.read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256'],f['file']
for p in list((root/'Anwendungen').glob('*.zip'))+list((root/'Beispiel').glob('*.zip')):
 with zipfile.ZipFile(p)as z,tempfile.TemporaryDirectory(prefix='ocr-check-')as folder:
  assert z.testzip()is None;z.extractall(folder)
  for n in z.namelist():assert pathlib.Path(folder,n).read_bytes()==z.read(n)
print(str(len(manifest))+' Dateien SHA-256-geprüft; alle Produkt-ZIPs vollständig und CRC-fehlerfrei entpackt.')
